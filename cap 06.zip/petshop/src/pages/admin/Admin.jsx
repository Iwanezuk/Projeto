import ListaCatAdmin from "./components/ListaCatAdmin";

const Admin = () => {
    return(
        <main>
            <div className="container">
                <h2 className="titulo-pagina">Administração</h2>
            </div>
            <ListaCatAdmin />
        </main> 
    )
}

export default Admin
