// import '../../assets/css/blog.css';
import '../assets/css/blog.css';
// import ListaPostAdmin from './components/ListaPostAdmin';
import ListaPostAdmin from './admin/components/ListaPostAdmin';

const PostAdmin = () => {
    
    return (
        <>
            <ListaPostAdmin />
        </>
    )
}

export default PostAdmin