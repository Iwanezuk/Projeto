import ListaCatAdmin from "./components/ListaCatAdmin";

const Admin = () => {
    return(
        <main>
            <ListaCatAdmin />
        </main> 
    )
}

export default Admin
